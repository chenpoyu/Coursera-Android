package course.labs.notificationslab;

interface SelectionListener {
	public void onItemSelected(int position);
	public boolean canAllowUserClicks();
}